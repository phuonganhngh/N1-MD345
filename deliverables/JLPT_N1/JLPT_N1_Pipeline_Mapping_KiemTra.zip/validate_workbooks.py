import fitz,json,hashlib,numpy as np
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
from collections import defaultdict
import build_workbooks as b
R=Path(__file__).parent;out=R/'output';dest=R/'inspection'/'rendered';dest.mkdir(exist_ok=True)
man=json.load(open(R/'output_manifest.json'));mapping=json.load(open(R/'crop_mapping.json'));pages=json.load(open(R/'page_mapping.json'));model=json.load(open(R/'model.json'))
mp=defaultdict(list)
for m in mapping:mp[(m['output_file'],m['output_page'])].append(m)
meta={(p['output_file'],p['page']):p for p in pages}
report={'files':[],'errors':[],'render_warnings':[],'crop_checks':0,'crop_reviews':[],'source_unchanged':True}
for s in model:
 if hashlib.sha256(b.source_path(b.SOURCES[s['key']]).read_bytes()).hexdigest()!=s['source_sha256']:report['source_unchanged']=False
for entry in man:
 file=entry['file'];d=fitz.open(out/file);thumb=[]
 for pn,p in enumerate(d,1):
  fitz.TOOLS.mupdf_warnings(reset=True)
  pix=p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);aa=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,3)
  im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.save(dest/f"{entry['mondai']}-{entry['group']:02d}-{pn:03d}.jpg",quality=82)
  small=im.copy();small.thumbnail((180,255));thumb.append(small)
  warns=fitz.TOOLS.mupdf_warnings(reset=True)
  if warns:report['render_warnings'].append([file,pn,warns])
  if p.rotation or abs(p.rect.width-b.W)>.1 or abs(p.rect.height-b.H)>.1:report['errors'].append([file,pn,'page dimensions/rotation'])
  pm=meta[(file,pn)]
  # Continuations before answer pages still belong to question section.
  question_section=pm['kind']=='questions' or (entry['mondai']==5 and any(m['kind'].startswith('question_') for m in mp[(file,pn)]))
  if question_section:
   red=(aa[:,:,0]>140)&(aa[:,:,1]<130)&(aa[:,:,2]<130)&(aa[:,:,0].astype(int)-aa[:,:,1].astype(int)>70)
   if red.sum()>3:report['errors'].append([file,pn,'red on question page',int(red.sum())])
  for m in mp[(file,pn)]:
   src=fitz.Rect(m['source_bbox']);dst=fitz.Rect(m['destination_bbox']);sx=dst.width/src.width;sy=dst.height/src.height
   if abs(sx-sy)>1e-5 or abs(sx-.93)>1e-5 or dst.x0<b.M-.2 or dst.x1>b.W-b.M+.2 or dst.y0<105.8 or dst.y1>b.BOTTOM+.2:report['errors'].append([file,pn,'crop geometry',m])
   doc=b.black_copy(m['source_key']) if m['color_variant']=='question_black' else b.DOCS[m['source_key']]
   ep=doc[m['source_page']-1].get_pixmap(matrix=fitz.Matrix(1.86,1.86),clip=src,alpha=False)
   expected=np.frombuffer(ep.samples,dtype=np.uint8).reshape(ep.height,ep.width,3).min(2)<190
   x0,y0,x1,y1=map(int,[np.floor(dst.x0*2),np.floor(dst.y0*2),np.ceil(dst.x1*2),np.ceil(dst.y1*2)])
   actual=aa[y0:y1,x0:x1].min(2)<190
   hh=max(expected.shape[0],actual.shape[0]);ww=max(expected.shape[1],actual.shape[1]);em=np.zeros((hh,ww),np.uint8);am=em.copy();em[:expected.shape[0],:expected.shape[1]]=expected*255;am[:actual.shape[0],:actual.shape[1]]=actual*255
   ed=np.asarray(Image.fromarray(em).filter(ImageFilter.MaxFilter(5)))>0;ad=np.asarray(Image.fromarray(am).filter(ImageFilter.MaxFilter(5)))>0
   recall=float((expected & ad[:expected.shape[0],:expected.shape[1]]).sum()/max(1,expected.sum()));precision=float((actual & ed[:actual.shape[0],:actual.shape[1]]).sum()/max(1,actual.sum()))
   report['crop_checks']+=1
   if min(recall,precision)<.88:report['crop_reviews'].append({'file':file,'page':pn,'kind':m['kind'],'question':m.get('question'),'source_key':m['source_key'],'source_page':m['source_page'],'source_bbox':list(src),'destination_bbox':list(dst),'recall':recall,'precision':precision})
 cols=5;can=Image.new('RGB',(cols*195,((len(thumb)+cols-1)//cols)*280),'#eeeeee');dr=ImageDraw.Draw(can)
 for i,t in enumerate(thumb):xx=(i%cols)*195;yy=(i//cols)*280;can.paste(t,(xx,yy+18));dr.text((xx,yy),str(i+1),fill='black')
 can.save(R/'inspection'/f"contact-M{entry['mondai']}-{entry['group']:02d}.jpg")
 report['files'].append({**entry,'pages':len(d),'sha256':hashlib.sha256((out/file).read_bytes()).hexdigest(),'rendered_all_pages':True});print('CHECKED',file,len(d),flush=True)
 d.close()
report['page_count']=sum(x['pages'] for x in report['files']);report['counts']={str(md):sum(len(s['mondai'][str(md)]) for s in model) for md in [3,4,5]}
report['missing_data']=json.load(open(R/'missing_data.json'));report['success']=not report['errors'] and not report['render_warnings'] and report['source_unchanged']
(R/'validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('RESULT',report['page_count'],'pages',report['crop_checks'],'crops','errors',len(report['errors']),'warnings',len(report['render_warnings']),'review crops',len(report['crop_reviews']))
