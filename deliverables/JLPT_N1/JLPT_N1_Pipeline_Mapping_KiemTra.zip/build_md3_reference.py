"""Rebuild only N1 Mondai 3 with source clips and the supplied N2 workbook's layout."""
import json,fitz,sys
from pathlib import Path
import build_workbooks as b
R=b.ROOT;OUT=R/'output';M=48.;W,H=fitz.paper_size('a4');BOTTOM=H-54;S=.93
FD=R/'fonts';REG=FD/'DejaVuSans.ttf';BOLD=FD/'DejaVuSans-Bold.ttf'
INCLUDE='--without-questions' not in sys.argv
ALL=[];PAGES=[];FILES=[]
def chunks(s,q):
 rows=[dict(r) for r in q['script']]
 if INCLUDE:
  end=q['script'][-1]['p']*1000+q['script'][-1]['bbox'][1]
  rows += [dict(r) for r in q['rows'] if r['p']*1000+r['bbox'][1]>end+.2]
 first=rows[0];out=[{'p':first['p'],'bbox':first['bbox'],'kind':'script_intro','gap':6.}]
 rem=rows[1:]
 while rem:
  pp=rem[0]['p'];rr=[r for r in rem if r['p']==pp];rem=[r for r in rem if r['p']!=pp]
  xx=min(r['bbox'][0] for r in rr);right=max(r['bbox'][2] for r in rr)
  # Preserve complete source line spacing and Japanese resources as a continuous PDF region.
  out.append({'p':pp,'bbox':[xx,rr[0]['bbox'][1],right,rr[-1]['bbox'][3]],'kind':'script_with_questions' if INCLUDE else 'script_body','gap':7.})
 return out
class ReferenceWorkbook:
 def __init__(self,group,sets):
  self.group=group;self.sets=sets;self.doc=fitz.open();self.page=None;self.key=None;self.y=0;self.mapping=[];self.meta=[];self.q=None
 def text(self,x,y,t,size=10,bold=False,color=(.122,.122,.122)):
  self.page.insert_font(fontname='refB' if bold else 'refR',fontfile=str(BOLD if bold else REG))
  self.page.insert_text((x,y),t,fontname='refB' if bold else 'refR',fontsize=size,color=color)
 def page_new(self,key=None,first=False):
  if key:self.key=key
  self.page=self.doc.new_page(width=W,height=H);n=len(self.doc)
  self.page.draw_line((M,H-49),(W-M,H-49),color=(.8,.8,.8),width=.45)
  self.text(M,H-29,'JLPT N1  |',7.5,color=(.4,.4,.4))
  self.page.insert_text((M+45,H-29),'問題3',fontname='japan',fontsize=7.5,color=(.4,.4,.4))
  self.text(M+75,H-29,'|  '+b.setname(self.key),7.5,color=(.4,.4,.4));self.text(W-M-7,H-29,str(n),7.5,color=(.4,.4,.4))
  if first:
   self.text(M,57,'JLPT N1',9,True,(.4,.4,.4));self.text(M,87,b.setname(self.key),25,True)
   self.page.insert_text((M,112),'問題3',fontname='japan',fontsize=16)
   self.page.draw_line((M,129),(W-M,129),color=(.8,.8,.8),width=.6);self.y=146
  else:
   self.text(M,58,'SCRIPT',9,True,(.4,.4,.4));self.page.draw_line((M,68),(W-M,68),color=(.8,.8,.8),width=.6);self.y=76
  self.meta.append({'output_file':self.filename(),'page':n,'set':self.key,'mondai':3,'kind':'answers_and_scripts' if first else 'script_continuation'})
 def filename(self):return f"N1_Mondai3_Nhom{self.group:02d}_"+'_'.join(b.setname(s['key']) for s in self.sets)+'.pdf'
 def place(self,r,x,kind):
  bb=fitz.Rect(r['bbox']);dst=fitz.Rect(x,self.y,x+bb.width*S,self.y+bb.height*S)
  assert dst.x0>=M-.01 and dst.x1<=W-M+.1 and dst.y1<=BOTTOM+.1,(self.key,self.q,kind,list(dst),r)
  self.page.show_pdf_page(dst,b.DOCS[self.key],r['p'],clip=bb,keep_proportion=True)
  self.mapping.append({'output_file':self.filename(),'output_page':len(self.doc),'set':self.key,'mondai':3,'question':self.q,'kind':kind,'source_key':self.key,'source_page':r['p']+1,'source_bbox':list(bb),'destination_bbox':list(dst),'scale':S,'rotation':0,'color_variant':'original'})
  self.y=dst.y1
 def answers(self,s):
  self.text(M,self.y+11,'ANSWER',10,True);self.y+=28
  for q in s['mondai']['3']:
   self.q=q['q'];rr=b.ink_trim(self.key,q['options'][q['answer']-1]);hh=fitz.Rect(rr['bbox']).height*S
   self.text(M,self.y+11,f"Q{q['q']}",10,True,(.278,.278,.278))
   y=self.y;self.place(rr,M+40,'answer_choice');self.y=y+max(28,hh+8)
  self.y+=5;self.page.draw_line((M,self.y),(W-M,self.y),color=(.8,.8,.8),width=.6);self.y+=16
  self.text(M,self.y+10,'SCRIPT',10,True);self.y+=26
 def script(self,q):
  self.q=q['q'];cc=chunks(next(s for s in self.sets if s['key']==self.key),q)
  total=18+sum(fitz.Rect(c['bbox']).height*S+c['gap'] for c in cc)+7
  if total<=BOTTOM-76 and self.y+total>BOTTOM:self.page_new()
  if self.y+35>BOTTOM:self.page_new()
  self.text(M,self.y+9,f"Q{q['q']}",10,True,(.278,.278,.278));self.y+=17
  for c in cc:
   bb=fitz.Rect(c['bbox']);full=bb.height*S
   if self.y+full<=BOTTOM:
    self.place(c,M+5 if bb.width*S<=W-2*M-5 else M,c['kind']);self.y+=c['gap'];continue
   # Split a question only if its complete source block is taller than the printable page.
   if total<=BOTTOM-76:raise AssertionError(('unexpected short block split',self.key,q['q']))
   rowcandidates=[r for r in q['rows'] if r['p']==c['p'] and bb.y0<=r['bbox'][1] and r['bbox'][3]<=bb.y1+.1]
   top=bb.y0
   while top<bb.y1-.1:
    limit=top+(BOTTOM-self.y)/S
    ends=[r['bbox'][3] for r in rowcandidates if top<r['bbox'][3]<=limit]
    if not ends:self.page_new();continue
    bottom=max(ends);piece={**c,'bbox':[bb.x0,top,bb.x1,bottom]};self.place(piece,M+5 if bb.width*S<=W-2*M-5 else M,c['kind'])
    remaining=[r for r in rowcandidates if r['bbox'][1]>=bottom]
    if not remaining:break
    top=remaining[0]['bbox'][1];self.page_new()
   self.y+=c['gap']
  self.y+=7
 def run(self):
  for s in self.sets:
   self.page_new(s['key'],first=True);self.answers(s)
   for q in s['mondai']['3']:self.script(q)
  fn=OUT/self.filename();self.doc.set_metadata({'title':f'JLPT N1 · 問題3 · Nhóm {self.group:02d}','subject':'Source PDF crops; layout matched to user N2 reference'})
  self.doc.save(fn,garbage=2,deflate=True);self.doc.close();ALL.extend(self.mapping);PAGES.extend(self.meta)
  FILES.append({'file':fn.name,'mondai':3,'group':self.group,'sets':[s['key'] for s in self.sets],'includes_questions':INCLUDE,'layout':'user_N2_reference'})
  print('REBUILT',fn.name,flush=True)
def main():
 groups=[b.MODEL[i:i+3] for i in range(0,27,3)]+[b.MODEL[27:]]
 for i,ss in enumerate(groups,1):ReferenceWorkbook(i,ss).run()
 for name,new in [('crop_mapping.json',ALL),('page_mapping.json',PAGES),('output_manifest.json',FILES)]:
  old=json.load(open(R/name));merged=[x for x in old if x['mondai']!=3]+new;(R/name).write_text(json.dumps(merged,ensure_ascii=False,indent=2))
 (R/'md3_reference_layout.json').write_text(json.dumps({'reference':'N2 MD3 (T7-2010, T12-2010, T7-2011).pdf','include_questions':INCLUDE,'margin':M,'scale':S,'first_page_header':True,'continuation_header':'SCRIPT','answers':'full original correct option crop','original_question_number_removed_from_intro':True,'question_count':176},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
