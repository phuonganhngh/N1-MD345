import json,re,fitz
from pathlib import Path
from collections import defaultdict
R=Path(__file__).parent;model={s['key']:s for s in json.load(open(R/'model.json'))};manifest=json.load(open(R/'output_manifest.json'));pm=json.load(open(R/'page_mapping.json'));maps=json.load(open(R/'crop_mapping.json'));errs=[];records=[]
for file in manifest:
 d=fitz.open(R/'output'/file['file']);pages=[p for p in pm if p['output_file']==file['file']];seen=[]
 for p in pages:
  if not seen or seen[-1]!=p['set']:seen.append(p['set'])
 if seen!=file['sets']:errs.append([file['file'],'source order',seen])
 for key in file['sets']:
  selected=[p for p in pages if p['set']==key];md=file['mondai'];qs=model[key]['mondai'][str(md)];texts=[]
  for meta in selected:
   tt=[]
   for bl in d[meta['page']-1].get_text('dict',flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)['blocks']:
    for line in bl.get('lines',[]):
     spans=[sp['text'] for sp in line['spans'] if sp['font'].startswith('NotoSans')]
     if spans:tt.append(''.join(spans))
   texts.append(tt)
  alltext=[t for page in texts for t in page];actual=[t.strip() for t in alltext if re.match(r'^Q\d',t.strip())]
  if md==3:expected=[f"Q{q['q']}  {q['answer']}" for q in qs]+[f"Q{q['q']}" for q in qs]
  elif md==4:expected=[f"Q{q['q']}" for q in qs]
  else:
   questions=[];answers=[];scripts=[]
   for q in qs:
    if q.get('subquestions'):
     questions += [f"Q{q['q']}.{i+1}" for i in range(2)]
     answers += [f"Q{q['q']}.{i+1}-{sub['answer']}" for i,sub in enumerate(q['subquestions'])]
     scripts += [f"Q{q['q']}.1 / Q{q['q']}.2"]
    else:questions.append(f"Q{q['q']}");answers.append(f"Q{q['q']}-{q['answer']}");scripts.append(f"Q{q['q']}")
   expected=questions+answers+scripts
   ap=next(p for p in selected if p['kind']=='answers_and_scripts')
   firstown=[t for t in texts[selected.index(ap)] if re.match(r'^Q\d',t.strip())]
   if firstown[:len(answers)]!=answers:errs.append([key,md,'answers not first on following page'])
  if [' '.join(t.split()) for t in actual]!=[' '.join(t.split()) for t in expected]:errs.append([key,md,'labels/answer order',actual,expected])
  if md==4:
   rr=[m for m in maps if m['output_file']==file['file'] and m['set']==key]
   for q in qs:
    pp={m['output_page'] for m in rr if m['question']==q['q']}
    if len(pp)!=1:errs.append([key,md,q['q'],'situation/answer split'])
  records.append({'set':key,'mondai':md,'verified_labels_and_answers':len(expected),'start_page':selected[0]['page']})
result={'errors':errs,'checks':records,'success':not errs};(R/'structure_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('Structural checks:',len(records),'errors:',len(errs));print(errs[:5])
