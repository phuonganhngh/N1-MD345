# JLPT N1 — 問題3・4・5

Bản biên soạn từ 31 bộ nguồn do người dùng cung cấp, chia đúng 10 nhóm; mỗi nhóm có một PDF cho mỗi Mondai. Hai PDF cập nhật T12-2020 và T12-2022 chỉ cung cấp lựa chọn in đã xác minh; script lấy từ PDF script tương ứng. Không thêm kỳ thi T7-2020 hoặc nguồn không được cung cấp.

## Chạy lại từ mapping đã kiểm tra

1. Giải nén pipeline; giữ nguyên các file JSON và thư mục `fonts`.
2. Đặt 33 PDF nguồn trong cùng một thư mục, giữ tên file gốc.
3. Cài Python và các thư viện: `python -m pip install -r requirements.txt`.
4. Đặt biến môi trường `N1_SOURCE_DIR` trỏ tới thư mục PDF nguồn.
5. Chạy `python build_workbooks.py`; PDF được ghi vào `output/`.
6. Chạy `python validate_workbooks.py`; từng trang được render vào `inspection/rendered/`, kết quả lưu trong `validation_report.json`.

Có thể chạy riêng một Mondai: `python build_workbooks.py --mondai 5` sau lần chạy đầy đủ. Mapping của các Mondai khác được giữ lại.

Không cần OCR khi chạy lại từ `model.json`. Bản dựng dùng `show_pdf_page` để copy vùng gốc, không gõ lại nội dung Nhật. Text layer chỉ dùng để xác định tọa độ. Chữ đỏ chỉ đổi thành đen trong tài liệu nguồn tạm dùng cho trang câu hỏi 問題5; không ghi sửa PDF nguồn.

## Các file dữ liệu

- `model.json`: bộ/câu, đáp án và các vùng source đã xác minh.
- `sources.json`, `source_manifest.json`: PDF nguồn và SHA-256.
- `summary_notes.json`: bảng tóm tắt tiếng Việt và vị trí trích dẫn Nhật gốc.
- `crop_mapping.json`: PDF/trang output, bộ/câu, PDF/trang nguồn, source bbox, destination bbox, scale, rotation và biến thể màu.
- `page_mapping.json`, `output_manifest.json`: trang, nhóm và thứ tự bộ.
- `missing_data.json`: từng câu cần bổ sung lựa chọn có số.
- `boundary_ocr_audit.json`: chỉ các vùng nhỏ đã OCR để định vị keyword; OCR không được dùng để dựng nội dung Nhật.
- `validation_report.json`, `BAO_CAO_KIEM_TRA.md`: kết quả kiểm tra và các giới hạn dữ liệu nguồn.

Trước khi thay nguồn hoặc sửa đáp án, đối chiếu nguồn và cập nhật mapping có kiểm tra. Không chạy lại bước suy luận boundary một cách tự động để ghi đè mapping đã được kiểm tra trực quan.

## Bản 問題3 làm lại theo PDF N2 mẫu

`build_md3_reference.py` tái sử dụng source model và các hàm crop của pipeline hiện tại. `build_workbooks.py` gọi bản dựng này khi xuất 問題3. ANSWER chứa nguyên phương án đúng được crop, tiếp theo SCRIPT có câu hỏi và đủ 4 lựa chọn theo yêu cầu mới. Số câu vẫn theo N1 thực tế. Font Latin, header/footer, khoảng cách và trang tiếp nối theo mẫu. Không lặp lại số câu nguồn trong nhãn intro.

Có thể chạy riêng bằng `python build_md3_reference.py` rồi `python validate_workbooks.py --mondai 3` và `python check_structure.py`. Hai Mondai khác được giữ nguyên. Không cần OCR để dựng lại.
