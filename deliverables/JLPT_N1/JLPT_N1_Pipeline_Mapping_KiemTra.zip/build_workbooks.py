"""Reproducible source-PDF clipping; Japanese body text is never typeset again."""
import fitz,json,re,hashlib,math,os,sys,numpy as np
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).parent;OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
MODEL=json.load(open(ROOT/'model.json'));NOTES=json.load(open(ROOT/'summary_notes.json'));RASTER=json.load(open(ROOT/'raster.json'))
SOURCES={s['key']:s for s in json.load(open(ROOT/'sources.json'))}
def source_path(s):
 base=os.environ.get('N1_SOURCE_DIR')
 return Path(base)/Path(s['path']).name if base else Path(s['path'])
DOCS={k:fitz.open(source_path(s)) for k,s in SOURCES.items()}
W,H=fitz.paper_size('a4');M=43.0;BOTTOM=H-48;CW=W-2*M;SCALE=.93
FD=ROOT/'fonts' if (ROOT/'fonts').exists() else Path('/usr/share/fonts/truetype/noto')
FONT=str(FD/'NotoSans-Regular.ttf');BOLD=str(FD/'NotoSans-Bold.ttf')
VN=fitz.Font(fontfile=FONT);VB=fitz.Font(fontfile=BOLD)
BLACK={};ALL_MAPPING=[];PAGE_META=[]
def black_copy(key):
 if key in BLACK:return BLACK[key]
 d=fitz.open(stream=DOCS[key].tobytes(),filetype='pdf')
 for xref in range(1,d.xref_length()):
  if d.xref_get_key(xref,'Subtype')[1]=='/Image':
   try:
    pix=fitz.Pixmap(d,xref)
    if pix.n>=3 and pix.width*pix.height<=64:
     aa=np.frombuffer(pix.samples,dtype=np.uint8).reshape(-1,pix.n)
     red=(aa[:,0]>140)&(aa[:,1]<130)&(aa[:,2]<130)&((aa[:,0].astype(int)-aa[:,1])>70)
     if red.any():
      zz=aa[:,:3].copy();zz[red,:3]=0;d.xref_set_key(xref,'ColorSpace','/DeviceRGB');d.xref_set_key(xref,'BitsPerComponent','8');d.update_stream(xref,zz.tobytes())
   except RuntimeError:pass
 for p in d:
  for xf in p.get_contents():
   b=d.xref_stream(xf)
   def repl(m):
    r,g,bl=map(float,m.group(1,2,3));return b'0 0 0 '+m.group(4) if r>g+.3 and r>bl+.3 else m.group(0)
   b=re.sub(rb'([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+(rg|RG)\b',repl,b)
   d.update_stream(xf,b)
 BLACK[key]=d;return d
def setname(key):
 y,mo=key.split('-');return f'T{int(mo)}-{y}'
def wordwrap(text,width,size=9.2,bold=False):
 f=VB if bold else VN;ls=[];line=''
 for word in text.split():
  t=(line+' '+word).strip()
  if f.text_length(t,fontsize=size)>width and line:ls.append(line);line=word
  else:line=t
 if line:ls.append(line)
 return ls
def ink_trim(key,r,remove_number=False,width=None):
 b=fitz.Rect(r['bbox']);p=DOCS[key][r['p']];pix=p.get_pixmap(matrix=fitz.Matrix(3,3),clip=b,alpha=False)
 a=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,3);mask=a.min(2)<185;xs=np.where(mask.any(0))[0]
 if not len(xs):return dict(r)
 x0=b.x0+xs.min()/3-.6;x1=b.x0+(xs.max()+1)/3+.6
 if remove_number:
  # Remove only the printed choice index, retaining the source Japanese option text.
  ys=mask[5:] if mask.shape[0]>25 else mask
  xx=np.where(ys.any(0))[0]/3+b.x0
  gaps=[(xx[i],xx[i+1]) for i in range(len(xx)-1) if xx[i+1]-xx[i]>4 and xx[i]-x0<28]
  if gaps:x0=gaps[0][1]-.8
 if width and x1-x0>width:
  cut=x0+width;xx=np.where(mask.any(0))[0]/3+b.x0
  gaps=[(xx[i]+xx[i+1])/2 for i in range(len(xx)-1) if xx[i+1]-xx[i]>1 and cut-12<(xx[i]+xx[i+1])/2<=cut]
  x1=max(gaps) if gaps else cut-12
 return {**r,'bbox':[max(0,x0),b.y0,min(p.rect.width,x1),b.y1]}
def quote_clips(key,r,width):
 b=fitz.Rect(ink_trim(key,r)['bbox']);page=DOCS[key][r['p']]
 pix=page.get_pixmap(matrix=fitz.Matrix(4,4),clip=b,alpha=False)
 aa=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,3)
 ink=(aa.min(2)<200).any(0);coords=np.where(ink)[0]/4+b.x0
 gaps=[(coords[i]+coords[i+1])/2 for i in range(len(coords)-1) if coords[i+1]-coords[i]>=.5]
 # Source text coordinates identify complete glyph boundaries; no Japanese is rebuilt.
 ends=[]
 for bl in page.get_text('rawdict',flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES)['blocks']:
  for ln in bl.get('lines',[]):
   if ln['bbox'][1]<b.y1 and ln['bbox'][3]>b.y0:
    for sp in ln['spans']:
     if sp['size']>=9:
      ends.extend(c['bbox'][2] for c in sp['chars'])
 result=[];left=b.x0
 while b.x1-left>width:
  candidates=[g for g in gaps if left+width-45<=g<=left+width-1]
  preferred=[g for g in candidates if any(abs(g-e)<2 for e in ends)]
  if preferred:right=max(preferred)
  elif candidates:right=max(candidates)
  else:raise ValueError(('quote glyph boundary needs review',key,r))
  result.append({**r,'bbox':[left,b.y0,right,b.y1]});left=right
 result.append({**r,'bbox':[left,b.y0,b.x1,b.y1]})
 return result
def prompt_clip(key,r,sub=False):
 r=dict(r);b=fitz.Rect(r['bbox']);end=b.x1
 if r.get('red'):end=min(end,r['red'][0]-2)
 chars=[]
 for block in DOCS[key][r['p']].get_text('rawdict',flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES)['blocks']:
  for line in block.get('lines',[]):
   if line['bbox'][1]<b.y1 and line['bbox'][3]>b.y0:
    for sp in line['spans']:
     chars.extend(sp['chars'])
 # A trailing black source key (2018-12) is also removed from the question copy.
 for c in chars:
  if c['c'] in '1234１２３４' and c['bbox'][0]>b.x1-24 and c['bbox'][0]>b.x0+120:end=min(end,c['bbox'][0]-2)
 start=b.x0
 if sub:
  # Original subquestion label is replaced by Qx.1 / Qx.2, never retyped Japanese.
  candidates=[c for c in chars if c['c'] in '１２12' and b.x0<c['bbox'][0]<b.x0+40]
  if candidates:
   label=min(candidates,key=lambda c:c['bbox'][0]);edge=label['bbox'][2]
   punctuation=[c for c in chars if c['c'] in ':：' and edge-1<=c['bbox'][0]<=edge+5]
   if punctuation:edge=max(c['bbox'][2] for c in punctuation)
   body=[c for c in chars if c['c'].strip() and c['c'] not in ':：' and c['bbox'][0]>=edge-.2 and c['bbox'][0]<b.x0+100]
   start=min(c['bbox'][0] for c in body)-1 if body else edge+5
  else:start=b.x0+45
 return {**r,'bbox':[start,b.y0,end,b.y1]}
class Workbook:
 def __init__(self,md,group,keys):
  self.current_q=None;self.md=md;self.group=group;self.keys=keys;self.doc=fitz.open();self.mapping=[];self.pages=[];self.page=None;self.y=0;self.key=None
 def txt(self,x,y,text,size=10,bold=False,color=(.14,.18,.22)):
  self.page.insert_font(fontname='vnB' if bold else 'vn',fontfile=BOLD if bold else FONT)
  self.page.insert_text((x,y),text,fontsize=size,fontname='vnB' if bold else 'vn',color=color)
 def newpage(self,key=None,kind='content'):
  if key:self.key=key
  self.page=self.doc.new_page(width=W,height=H);pn=len(self.doc)
  self.txt(M,29,'JLPT N1',9.5,bold=True,color=(.32,.39,.43))
  self.txt(M,57,setname(self.key),22,bold=True)
  self.page.insert_text((M,78),f'問題{self.md}',fontname='japan',fontsize=13,color=(.14,.18,.22))
  self.page.draw_line((M,88),(W-M,88),color=(.78,.82,.84),width=.6)
  self.page.draw_line((M,H-34),(W-M,H-34),color=(.82,.85,.86),width=.4)
  self.txt(M,H-20,'JLPT N1 |',7.4,color=(.4,.45,.48))
  self.page.insert_text((M+45,H-20),f'問題{self.md}',fontname='japan',fontsize=7.4,color=(.4,.45,.48))
  self.txt(M+76,H-20,'| '+setname(self.key),7.4,color=(.4,.45,.48))
  self.txt(W-M-18,H-20,str(pn),7.4,color=(.4,.45,.48));self.y=106
  self.pages.append({'page':pn,'set':self.key,'mondai':self.md,'kind':kind})
 def ensure(self,height):
  if self.y+height>BOTTOM:self.newpage()
 def heading(self,text,size=11):self.ensure(size+12);self.txt(M,self.y+size,text,size,bold=True);self.y+=size+13
 def place(self,r,kind,x=None,scale=SCALE,black=False):
  key=r.get('source_key',self.key);b=fitz.Rect(r['bbox']);assert b.width>0 and b.height>0,(key,r)
  x=M if x is None else x;hh=b.height*scale;ww=b.width*scale
  assert x>=M-.1 and x+ww<=W-M+.2,(self.key,kind,x,ww,CW,r)
  self.ensure(hh);rect=fitz.Rect(x,self.y,x+ww,self.y+hh)
  src=black_copy(key) if black else DOCS[key];self.page.show_pdf_page(rect,src,r['p'],clip=b,keep_proportion=True)
  self.mapping.append({'output_page':len(self.doc),'set':self.key,'mondai':self.md,'kind':kind,'question':self.current_q,'source_key':key,'source_page':r['p']+1,'source_bbox':list(b),'destination_bbox':list(rect),'scale':scale,'rotation':0,'color_variant':'question_black' if black else 'original'})
  self.y+=hh
 def script(self,q):
  self.current_q=q['q'];rows=q['script'];left=min(r['bbox'][0] for r in rows if not r.get('remove_original_label')) if any(not r.get('remove_original_label') for r in rows) else rows[0]['bbox'][0]
  heights=[(r['bbox'][3]-r['bbox'][1])*SCALE+4.5 for r in rows];total=sum(heights)+27
  if total<=BOTTOM-106 and self.y+total>BOTTOM:self.newpage()
  label=f"Q{q['q']}.1 / Q{q['q']}.2" if q.get('subquestions') else f"Q{q['q']}"
  self.heading(label,10.5)
  for i,r in enumerate(rows):
   self.ensure(heights[i]);x=M if r.get('remove_original_label') or (i==0 and self.key=='2023-12') else M+max(0,r['bbox'][0]-left)*SCALE
   # Clamp only harmless outside padding; width never changes independently of height.
   if x+(r['bbox'][2]-r['bbox'][0])*SCALE>W-M:x=M
   self.place(r,'script',x=x);self.y+=4.5
  self.y+=9
 def vn_note(self,text,size=9):
  ls=wordwrap(text,CW,size);self.ensure(len(ls)*(size+4)+8)
  for l in ls:self.txt(M,self.y+size,l,size);self.y+=size+4
  self.y+=8
 def table(self,q,notes):
  cols=notes['cols'];widths=[CW/2]*2 if len(cols)==2 else [122,(CW-122)/2,(CW-122)/2]
  size=9.1;pad=7;rowparts=[];quote=notes.get('quote');qr=[]
  if quote:
   row,col,pno,y=quote;rr=[r for r in q['script'] if r['p']==pno-1]
   if rr:
    base=min(rr,key=lambda r:abs(r['bbox'][1]-y));qr=quote_clips(self.key,base,(widths[col]-2*pad)/SCALE)
  headerh=max(len(wordwrap(c,w-2*pad,9.2,True)) for c,w in zip(cols,widths))*12.8+2*pad
  for ri,row in enumerate(notes['rows']):
   lines=[wordwrap(t,w-2*pad,size) for t,w in zip(row,widths)]
   heights=[len(ll)*12.6+2*pad for ll in lines]
   if qr and quote[0]==ri:heights[quote[1]]+=sum((r['bbox'][3]-r['bbox'][1])*SCALE+3 for r in qr)+8
   rowparts.append((lines,max(max(heights),27)))
  total=headerh+sum(h for _,h in rowparts)+10
  if total<=BOTTOM-106 and self.y+total>BOTTOM:self.newpage()
  def header():
   self.ensure(headerh);yy=self.y;xx=M
   for c,w in zip(cols,widths):
    self.page.draw_rect(fitz.Rect(xx,yy,xx+w,yy+headerh),color=(.72,.77,.8),fill=(.94,.96,.97),width=.45)
    for j,l in enumerate(wordwrap(c,w-2*pad,9.2,True)):self.txt(xx+pad,yy+pad+9.2+j*12.8,l,9.2,True)
    xx+=w
   self.y+=headerh
  header()
  for ri,(lines,hh) in enumerate(rowparts):
   if self.y+hh>BOTTOM:self.newpage();header()
   yy=self.y;xx=M
   for ci,(ll,w) in enumerate(zip(lines,widths)):
    self.page.draw_rect(fitz.Rect(xx,yy,xx+w,yy+hh),color=(.75,.79,.82),width=.4)
    for j,l in enumerate(ll):self.txt(xx+pad,yy+pad+size+j*12.6,l,size)
    if qr and quote[0]==ri and quote[1]==ci:
     old=self.y;self.y=yy+pad+len(ll)*12.6+5;
     for piece in qr:self.place(piece,'table_quote',x=xx+pad);self.y+=3
     self.y=old
    xx+=w
   self.y=yy+hh
  self.y+=14
 def questions(self,qs):
  for q in qs:
   self.current_q=q['q'];items=q.get('subquestions') or [q]
   for i,it in enumerate(items):
    self.heading(f"Q{q['q']}.{i+1}" if q.get('subquestions') else f"Q{q['q']}",10.5)
    for r in it['prompt']:
     rr=prompt_clip(self.key,r,sub=bool(q.get('subquestions')));self.place(rr,'question_prompt',black=True);self.y+=6
    if it.get('missing_options'):
     self.vn_note('Cần bổ sung lựa chọn có số 1–4 từ nguồn hoặc bằng chứng xác nhận thứ tự.',8.8)
    else:
     opts=it['options'];assert len(opts)==4
     for n,r in enumerate(opts,1):
      native=bool(q.get('subquestions')) and not r.get('printed_number')
      key=r.get('source_key',self.key);rr=ink_trim(key,r,remove_number=not native)
      hh=(rr['bbox'][3]-rr['bbox'][1])*SCALE;self.ensure(hh+5)
      self.txt(M+3,self.y+min(hh-2,12),str(n),10)
      self.place(rr,'question_option',x=M+23,black=True);self.y+=5
    self.y+=6
 def runset(self,s):
  self.key=s['key'];qs=s['mondai'][str(self.md)];self.newpage(kind='questions' if self.md==5 else 'content')
  if self.md==3:
   self.heading('ANSWER',10.5)
   # Compact answer block, all answers before any script.
   for q in qs:self.txt(M,self.y+10,f"Q{q['q']}  {q['answer']}",10);self.y+=17
   self.y+=10;self.heading('SCRIPT',10.5)
   for q in qs:self.script(q)
  elif self.md==4:
   for q in qs:
    self.current_q=q['q'];left=min(r['bbox'][0] for r in q['script']);rr=q['script']+q['correct_response'];height=sum((r['bbox'][3]-r['bbox'][1])*SCALE+4 for r in rr)+29
    self.ensure(height);self.heading(f"Q{q['q']}",10.5)
    for r in q['script']:self.place(r,'situation',x=M);self.y+=5
    for r in q['correct_response']:self.place(r,'correct_response',x=M+11);self.y+=4
    self.y+=14
  else:
   self.questions(qs);self.newpage(kind='answers_and_scripts')
   for q in qs:
    if q.get('subquestions'):
     for i,sub in enumerate(q['subquestions']):self.txt(M,self.y+10,f"Q{q['q']}.{i+1}-{sub['answer']}",10);self.y+=17
    else:self.txt(M,self.y+10,f"Q{q['q']}-{q['answer']}",10);self.y+=17
   self.y+=13
   for q,notes in zip(qs,NOTES[self.key]):self.script(q);self.table(q,notes)
 def save(self):
  stem=f"N1_Mondai{self.md}_Nhom{self.group:02d}_"+'_'.join(setname(k) for k in self.keys)
  file=OUT/(stem+'.pdf');self.doc.set_metadata({'title':f"JLPT N1 · Mondai {self.md} · Nhóm {self.group:02d}",'author':'JLPT N1 study workbook','subject':'Original PDF clips with Vietnamese supplementary notes' if self.md==5 else 'Original PDF clips'})
  self.doc.save(file,garbage=2,deflate=True);self.doc.close()
  for m in self.mapping:m['output_file']=file.name
  for p in self.pages:p['output_file']=file.name
  ALL_MAPPING.extend(self.mapping);PAGE_META.extend(self.pages);return file
def main():
 groups=[MODEL[i:i+3] for i in range(0,27,3)]+[MODEL[27:]]
 assert [len(g) for g in groups]==[3]*9+[4]
 chosen=int(sys.argv[sys.argv.index('--mondai')+1]) if '--mondai' in sys.argv else None
 manifest=[]
 if chosen and (ROOT/'output_manifest.json').exists():
  manifest=[m for m in json.load(open(ROOT/'output_manifest.json')) if m['mondai']!=chosen]
  ALL_MAPPING.extend(m for m in json.load(open(ROOT/'crop_mapping.json')) if m['mondai']!=chosen)
  PAGE_META.extend(m for m in json.load(open(ROOT/'page_mapping.json')) if m['mondai']!=chosen)
 for gi,group in enumerate(groups,1):
  for md in ([chosen] if chosen else [3,4,5]):
   wb=Workbook(md,gi,[s['key'] for s in group])
   for s in group:wb.runset(s)
   f=wb.save();manifest.append({'file':f.name,'mondai':md,'group':gi,'sets':[s['key'] for s in group]});print(f.name,flush=True)
 (ROOT/'crop_mapping.json').write_text(json.dumps(ALL_MAPPING,ensure_ascii=False,indent=2));(ROOT/'page_mapping.json').write_text(json.dumps(PAGE_META,ensure_ascii=False,indent=2));(ROOT/'output_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
